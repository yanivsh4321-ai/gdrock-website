﻿GDROCK FREE STARTER PACK

Inside:
- GDPR Basics Guide (plain-English)
- 25-Step Compliance Checklist

Want everything done? Core Pack (privacy policy + cookie banner + breach pack) is just EUR29:
https://www.gdrock.com/checkout.html?plan=core

office@gdrock.com - we reply within 24h.
